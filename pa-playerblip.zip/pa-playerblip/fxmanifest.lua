fx_version 'cerulean'
game 'gta5'

author 'Project Alpha - moritzoida'
description 'Player Blips ESX Only'
version '1.0.0'

client_scripts {
    '@es_extended/imports.lua',
    'client.lua'
}

server_scripts {
    '@es_extended/imports.lua',
    'server.lua'
}